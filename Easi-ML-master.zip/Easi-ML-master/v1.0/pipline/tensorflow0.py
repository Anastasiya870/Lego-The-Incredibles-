# -*- coding: utf-8 -*-
"""
Created on Sat Mar 17 16:35:49 2018

@author: Administrator
"""

#%%
import tensorflow as tf
import pandas as pd
import numpy as np

#%%
